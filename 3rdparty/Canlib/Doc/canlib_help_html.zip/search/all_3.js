var searchData=
[
  ['data',['data',['../structkvm_log_msg_ex.html#a62823cfc5356727ed036cea88e873777',1,'kvmLogMsgEx']]],
  ['dealloc',['deAlloc',['../structtag_can_s_w_descr.html#a02d13eb86e10f0ce10d4f87ea08093a1',1,'tagCanSWDescr']]],
  ['device_5faddress',['device_address',['../structkvr_device_info.html#aa2b8d4e5c35518a9cf58723f8a48153c',1,'kvrDeviceInfo']]],
  ['device_20discovery',['Device Discovery',['../group___discovery.html',1,'']]],
  ['dlc',['dlc',['../structkvm_log_msg_ex.html#a7d3cf80248d9011329b4b269f8b7d2c4',1,'kvmLogMsgEx']]],
  ['databases',['Databases',['../group__kvadb__database.html',1,'']]],
  ['database',['Database',['../group__kvlc__database.html',1,'']]],
  ['device_20connection',['Device Connection',['../group__kvm__connection.html',1,'']]],
  ['databases',['Databases',['../group__kvm__database.html',1,'']]],
  ['disk_20operations',['Disk Operations',['../group__kvm__disk__operations.html',1,'']]],
  ['database_20api_20_28kvadblib_29',['Database API (kvaDbLib)',['../page_kvadblib.html',1,'']]]
];
