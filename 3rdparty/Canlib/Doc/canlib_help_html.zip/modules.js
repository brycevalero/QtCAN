var modules =
[
    [ "CANlib", "group__grp__canlib.html", "group__grp__canlib" ],
    [ "LINlib", "group__grp__linlib.html", "group__grp__linlib" ],
    [ "kvaDbLib", "group__grp__kvadb.html", "group__grp__kvadb" ],
    [ "kvlclib", "group__grp__kvlc.html", "group__grp__kvlc" ],
    [ "kvmlib", "group__grp__kvm.html", "group__grp__kvm" ],
    [ "kvaMemoLibXML", "group__grp__kvaxml.html", "group__grp__kvaxml" ],
    [ "kvrlib", "group__grp__kvrlib.html", "group__grp__kvrlib" ]
];