var NAVTREE =
[
  [ "Welcome to Kvaser CANlib SDK!", "index.html", [
    [ "CAN bus API (CANlib)", "page_canlib.html", "page_canlib" ],
    [ "LIN bus API (LINlib)", "page_linlib.html", [
      [ "Using the LIN Bus", "page_linlib.html#section_user_guide_lin_intro", null ]
    ] ],
    [ "Database API (kvaDbLib)", "page_kvadblib.html", [
      [ "Description", "page_kvadblib.html#section_user_guide_kvadblib_1", null ],
      [ "Naming convention", "page_kvadblib.html#section_user_guide_kvadblib_2", null ],
      [ "Build an application", "page_kvadblib.html#section_user_guide_kvadblib_3", [
        [ "Example", "page_kvadblib.html#section_user_guide_kvadblib_3_3", null ]
      ] ]
    ] ],
    [ "Converter API (kvlclib)", "page_kvlclib.html", [
      [ "Description", "page_kvlclib.html#section_user_guide_kvlclib_1", null ],
      [ "Naming convention", "page_kvlclib.html#section_user_guide_kvlclib_2", null ],
      [ "Build an application", "page_kvlclib.html#section_user_guide_kvlclib_3", null ]
    ] ],
    [ "Memorator API (kvmlib)", "page_kvmlib.html", [
      [ "Description", "page_kvmlib.html#section_user_guide_kvmlib_1", null ],
      [ "Naming convention", "page_kvmlib.html#section_user_guide_kvmlib_2", null ],
      [ "Build an application", "page_kvmlib.html#section_user_guide_kvmlib_3", null ]
    ] ],
    [ "Memorator XML API (kvaMemoLibXML)", "page_kvamemolibxml.html", [
      [ "Description", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_1", null ],
      [ "Build an application", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_2", null ]
    ] ],
    [ "Remote Device API (kvrlib)", "page_kvrlib.html", [
      [ "Device discovery", "page_kvrlib.html#section_discovery", null ],
      [ "Local Configuration", "page_kvrlib.html#section_configuration", null ],
      [ "Network information", "page_kvrlib.html#section_network", null ]
    ] ],
    [ "License and Copyright", "page_license_and_copyright.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_c_l_rcandump_8cpp-example.html",
"canlib_8h.html#ad6cf5e581fd3486228e58bf350eebb43",
"group___c_a_n.html#gab0c7c4b4949146d131c8a0afd6097901",
"group___object_buffers.html#ga8385ea3d2278fb45cf2a11042940b92b",
"group__kvadb__attributes.html#ga260cd9cb2cccec515596389e51556f5b",
"group__kvadb__signals.html#gabf8723b14dafc4597cd68d72a0608884",
"group__lin__status__codes.html#gga7a5ecfd2846ddd76cd49fb4edec7fc14a4410cb44bc89862bb4f8e2ec21b546cc",
"kvlclib_8h.html#a0accd9bdefac8fd28e2f91f310bc31fb",
"linlib_8h.html#a8c2ab5dd117f814cef07f6b072aaafc9",
"structkvr_device_info.html#ae67e2c0ec4e8c9e9504a0f38e7415084"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';