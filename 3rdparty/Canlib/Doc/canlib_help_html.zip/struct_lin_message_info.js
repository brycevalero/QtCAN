var struct_lin_message_info =
[
    [ "bitrate", "struct_lin_message_info.html#ae1500e00270cc662f39a27c2f2d23962", null ],
    [ "byteTime", "struct_lin_message_info.html#a49b9c16add79f98b4f26894ae8f44356", null ],
    [ "checkSum", "struct_lin_message_info.html#a0890e48334b4123d76276b8341d3d82c", null ],
    [ "frameLength", "struct_lin_message_info.html#aedcbabfa0a2b5302ee5b5000812096f3", null ],
    [ "idPar", "struct_lin_message_info.html#ab657e630aa9b3cd5acfcaec6f914a498", null ],
    [ "synchBreakLength", "struct_lin_message_info.html#a137ad7080687a2011666ac9eafe0832f", null ],
    [ "synchEdgeTime", "struct_lin_message_info.html#a2eb7b88360a5994c5a4f49f02138c0f0", null ],
    [ "timestamp", "struct_lin_message_info.html#acba7776dcc1861edfe0e9c5736de4df8", null ],
    [ "z", "struct_lin_message_info.html#ae62c3a70821ab3195b683d473e98a5d7", null ]
];