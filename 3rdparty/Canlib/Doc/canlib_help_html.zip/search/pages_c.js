var searchData=
[
  ['virtual_20channels',['Virtual Channels',['../page_user_guide_virtual.html',1,'page_user_guide']]]
];
