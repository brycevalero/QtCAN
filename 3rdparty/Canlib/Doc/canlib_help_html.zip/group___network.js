var group___network =
[
    [ "kvrHostName", "group___network.html#gaa8fb74da18bdd48243bdd7e43b4f1da5", null ],
    [ "kvrNetworkConnectionTest", "group___network.html#gaa983cf52a7b27b256f623b9a6555aa89", null ],
    [ "kvrNetworkGetAddressInfo", "group___network.html#gaa0105990c76e32db61c2c5c8eb4fe699", null ],
    [ "kvrNetworkGetConnectionStatus", "group___network.html#ga8c71a0aaf847c42dc42577dce38df3d6", null ],
    [ "kvrNetworkGetHostName", "group___network.html#gaae47c6d5783f51457f307f01cc8f1e1f", null ],
    [ "kvrNetworkGetRssiRtt", "group___network.html#gaf7ed9134a9f954855cc4d8eee0658dea", null ],
    [ "kvrWlanGetScanResults", "group___network.html#ga43b442432149bdf27109ddc4a68adf92", null ],
    [ "kvrWlanStartScan", "group___network.html#ga5e9008f01c43ce74e8a98addb8044160", null ]
];