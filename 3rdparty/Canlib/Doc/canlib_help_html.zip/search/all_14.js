var searchData=
[
  ['validation',['Validation',['../group__kvaxml__validation.html',1,'']]],
  ['virtual_20channels',['Virtual Channels',['../page_user_guide_virtual.html',1,'page_user_guide']]],
  ['ver',['ver',['../structkvm_log_event_ex.html#a98bf6dca6b83720d147fc6197143d631',1,'kvmLogEventEx']]],
  ['version',['version',['../struct_j1587_message_info.html#a278ac8112eb4d891fdffa2a26fb4de69',1,'J1587MessageInfo::version()'],['../structkvr_cipher_info_element.html#acd99bb05ca015e7d74448acb1deba7ca',1,'kvrCipherInfoElement::version()']]]
];
