var group__kvm__configuration =
[
    [ "kvmKmfReadConfig", "group__kvm__configuration.html#gaefc3b927116a224ce46374214eea6adb", null ],
    [ "kvmKmfWriteConfig", "group__kvm__configuration.html#ga936bf0bc4d7f4dd03b9b367477e43183", null ]
];