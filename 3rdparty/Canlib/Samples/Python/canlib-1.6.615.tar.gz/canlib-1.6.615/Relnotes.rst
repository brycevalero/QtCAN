===========================================================================
                            Release Notes
===========================================================================
This is the release notes for the pycanlib module.

.. contents::
    :depth: 2


New Features and Fixed Problems in V1.6.615  (13-MAY-2018)
===========================================================================

* Updated for CANlib SDK v5.23.

* Getting version numbers should now be done with ``dllversion()``,
  which will return `canlib.BetaVersionNumber` if the dll is marked as Beta.
  Also added ``canlib.prodversion()`` to return the CANlib product version number.

* `canlib.device`:

  - New `canlib.device.Device` class (available as `canlib.Device`) that is a
    simpler version of kvDevice. `canlib.device.Device` objects can be defined
    using an EAN and serial number, or a connected device can be searched for
    using `canlib.device.Device.find`. These objects do not require the device
    to stay connected, and can be used to later create most other `canlib`
    objects, e.g. `canlib.canlib.Channel`, `canlib.kvmlib.Memorator`, etc.

  - New `canlib.device.connected_devices` which returns an iterator of
    `canlib.device.Device` objects, one for each device currently connected.

* `canlib.ean`:

  - `canlib.ean.EAN` objects can be tested for equality, both with other
    `canlib.ean.EAN` objects and with strings.

  - Added `CanNotFound` exception.

  - `canlib.ean.EAN` objects can now be directly instantiated from string,
    i.e. ``ean = canlib.EAN(ean_string)`` instead of ``ean =
    canlib.EAN.from_string(ean_string)``.

  - `canlib.ean.EAN` objects can be converted back into any of the
    representations that can be used to create them. See the documentation of
    `canlib.ean.EAN` for more info.

  - `canlib.ean.EAN` objects can be indexed and iterated upon, yielding the
    digits as `int`\s.

* `canlib.canlib`:

  - `canlib.canlib.EnvVar` object raises `EnvvarNameError` when given an
    illegal name, instead of `AssertionError`.

  - `canlib.canlib.openChannel` can now set the bitrate of the channel opened.

  - `canlib.canlib.Channel` objects automatically close their handles when
    garbage collected

* `canlib.kvamemolibxml`:

  - A new, object oriented way of dealing with kvamemolibxml using
    `canlib.kvamemolibxml.Configuration` objects.

* `canlib.kvmlib`:

  - Improved object model

    + New `canlib.kvmlib.openDevice` function that returns a
      `canlib.kvmlib.Memorator` object representing a connected Memorator
      device. See the documentation of `canlib.kvmlib.Memorator` for
      instructions on how to use this new class to more easily interface with
      your Memorators.

    + New `canlib.kvmlib.openKmf` function for opening .KMF files that returns
      a `canlib.kvmlib.Kmf` object that is similar to
      `canlib.kvmlib.Memorator`. See the docstring of `canlib.kvmlib.Kmf` for
      more information.

* `canlib.linlib`:

  - Getting version number with `canlib.linlib.dllversion` (requires CANlib SDK
    v5.23 or newer).

  - Explicit `canlib.linlib.Channel.close` function for forcing a linlib
    channel's internal handle to be closed.

* `canlib.canlib`:

  - Added support for accessing information within compiled t program (.txe) files.

    + Added wrapper function for `kvScriptTxeGetData`.
    + Added compiled t program (.txe) interface class `canlib.canlib.Txe`.

* `canlib.kvadblib`:

  - enums now returns non-empty dictionary in attribute definition returned
    from `EnumDefinition.definition`


New Features and Fixed Problems in V1.5.525  (12-FEB-2018)
===========================================================================

* Updated for CANlib SDK v5.22.

* Added support for LIN bus API (LINlib)

* Added support for Database API (kvaDbLib)
  Needs version v5.22 of CANlib SDK to get supported dll.

Restructuring of code in order to make the API simpler and the code base more
maintainable have resulted in the following changes (old style is deprecated,
shown in details while running Python with the -Wd argument):

* `canlib.kvMessage` has been renamed `canlib.Frame`

  - `canlib.Frame` objects are now accepted and returned when writing and reading channels.
  - The new `canlib.kvadblib` module uses these `canlib.Frame` objects heavily.

* `canlib.canlib`:

  - Added wrapper functions for `canReadStatus` and `canRequestChipStatus`
  - Deprecated use of `canlib.canlib.canlib()` objects; all methods have been moved to the module.

    + See the docstring of `canlib.canlib.CANLib` for more information

  - Simplified the names of the channel-classes (old names are deprecated):

    + The channel class is now `canlib.canlib.Channel`, instead of `canlib.canChannel`.
    + `canlib.canlib.ChannelData_Channel_Flags` is now `canlib.canlib.ChannelFlags`
    + `canlib.canlib.ChannelData_Channel_Flags_bits` is now `canlib.canlib.ChannelFlagBits`

  - `canlib.canlib.Channel` now uses `canlib.Frame` objects for reading and writing.

    + `canlib.Channel.read` now returns a `canlib.Frame` object instead of a tuple. However, `canlib.Frame` objects are largely compatible with tuples.
    + `canlib.Channel.write` takes a single argument, a `canlib.Frame` object. The previous call signature has been taken over by `canlib.Channel.write_raw`.
    + Likewise for `canlib.Channel.writeWait` and its new friend `canlib.Channel.writeWait_raw`.

  - The class `canlib.canlib.canVersion` has been removed, and
    `canlib.canlib.getVersion` now returns a `canlib.VersionNumber`. The new
    class still supports conversion to string and accessing ``.major`` and
    ``.minor`` attributes.

* `canlib.kvmlib`:

  - Added wrapper functions for kvmKmeReadEvent.
  - Corrected encoding for Python 3 in kmeOpenFile().
  - Deprecated names for several classes to make them more logical and more pythonic:

    + `canlib.kvmlib.memoMsg` is now `canlib.kvmlib.LogEvent`
    + `canlib.kvmlib.logMsg` is now `canlib.kvmlib.MessageEvent`
    + `canlib.kvmlib.rtcMsg` is now `canlib.kvmlib.RTCEvent`
    + `canlib.kvmlib.trigMsg` is now `canlib.kvmlib.TriggerEvent`
    + `canlib.kvmlib.verMsg` is now `canlib.kvmlib.VersionEvent`

  - The class `canlib.kvmlib.kvmVersion` has been removed, and
    `canlib.kvmlib.KvmLib.getVersion` now returns a `canlib.VersionNumber`. The
    new class still supports conversion to string and accessing ``.major``,
    ``.minor``, and ``.build`` attributes.

* `canlib.kvlclib`:

  - Added method `canlib.kvlclib.addDatabaseFile` and helper object `canlib.kvlclib.ChannelMask`.

  - The `canlib.kvlclib.KvlcLib` object has been deprecated.

    + All functions that relate to converters have been moved to the more appropriately named `canlib.kvlclib.Converter`.

      - Some of these functions have been renamed:

        + `IsOutputFilenameNew`, `IsOverrunActive`, and `IsDataTruncated` have all had their initial "i" lower-cased, as the upper case "I" was an error.
        + `getPropertyDefault` and `isPropertySupported` are no longer available on the `Converter` object, they must be accessed via the `format` attribute::

            converter.format.getPropertyDefault(...)
    + `canlib.kvlclib.WriterFormat.getFirstWriterFormat` and `canlib.kvlclib.WriterFormat.getNextWriterFormat` now returns a `kvlclib.FileFormat` object (which is based on the `IntEnum` class).

    + Other functions have been moved to the `canlib.kvlclib` module.
    + `deleteConverter` is no longer supported. Instead, converters are automatically deleted when garbage collected. If their contents must be flushed to file, see the new `canlib.kvlclib.Converter.flush` method.

  - The class `canlib.kvlclib.KvlcVersion` has been removed, and
    `canlib.kvmlib.kvlclib.getVersion` now returns a `canlib.VersionNumber`. The
    new class still supports conversion to string and accessing ``.major``,
    ``.minor``, and ``.build`` attributes.


* `canlib.kvrlib`:

  - The `canlib.kvrlib.KvrLib` object has been deprecated; all methods have been moved to the module.

  - `canlib.kvrlib.getVersion` no longer returns a `canlib.kvrlib.kvrVersion`
    but a `canlib.VersionNumber`. The return value still supports conversion to
    string and accessing ``.major`` and ``.minor`` attributes.

* `canlib.kvamemolibxml`:

  - Renamed from `canlib.KvaMemoLibXml`, however trying to import the old name will just import the new one instead.
  - Deprecated the use of `canlib.kvamemolibxml.KvaMemoLib` objects, all methods have been moved to the `canlib.kvamemolibxml` module itself.
  - Breaking change: Moved values that were incorrectly defined as constants into enums. In most cases this should not have any impact, as all the values are internal error codes and are turned into Python exceptions. But if you nonetheless use the kvamemolibxml status values directly, you'll need to change your code as follows:

    + ``KvaXmlStatusERR_XXX_XXX`` is now ``Error.XXX_XXX``.
    + ``KvaXmlValidationStatusERR_XXX_XXX`` is now ``ValidationError.XXX_XXX``
    + ``KvaXmlValidationStatusWARN`` is now ``ValidationWarning.XXX_XXX``.
    + ``KvaXmlStatusFail`` is now ``Error.FAIL`` (Changed to be consistent with other KvaXmlStatus errors). The same is true for ``ValidationError.FAIL``.
    + ``KvaXmlStatusOK`` and ``KvaXmlValidationStatusOK`` are still treated as if they are constants, as they are not error statuses.

  - `canlib.kvamemolibxml.getVersion` no longer returns a string but a
    `canlib.VersionNumber`. The return value still supports conversion to
    string.

* Exceptions:

  - Exceptions throughout the package have been standardised, and now all inherit from `canlib.exceptions.CanlibException`.
  - The `canERR` attribute that some exceptions had has been deprecated in favour of a `status` attribute. Furthermore, all `canlib` exceptions now have this attribute; the status code that was returned from a C call that triggered the specific exception.


New Features and Fixed Problems in V1.4.373  (13-SEP-2017)
===========================================================================
* Minor changes.


New Features and Fixed Problems in V1.3.242  (05-MAY-2017)
===========================================================================
* Added missing unicode conversions for Python3.

* Linux

  - Added support for new libraries (kvadblib, kvmlib, kvamemolibxml, kvlclib).
  - Added wrappers KvFileGetCount, kvFileGetName, kvFileCopyXxxx, kvDeviceSetMode, kvDeviceGetMode

* canlib:

  - Added wrapper for kvFileDelete
  - Enhanced printout from canScriptFail errors.
  - Second file argument in fileCopyFromDevice and fileCopyToDevice is now optional.
  - OS now loads all dependency dll (also adding KVDLLPATH to PATH in Windows).


New Features and Fixed Problems in V1.2.163  (15-FEB-2017)
===========================================================================
* Added wrapper function canlib.getChannelData_Cust_Name()
* Added module canlib.kvlclib which is a wrapper for the Converter Library
  kvlclib in CANlib SDK.

* Added wrapper function canChannel.flashLeds().

* Added missing unicode conversions for Python3.

* Fixed bug where CANlib SDK install directory was not always correctly
  detected in Windows 10.


New Features and Fixed Problems in V1.1.23  (28-SEP-2016)
===========================================================================
* canSetAcceptanceFilter and kvReadTimer was not implemented in Linux


New Features and Fixed Problems in V1.0.10  (15-SEP-2016)
===========================================================================
* Initial module release.

* Added kvmlib.kmeSCanFileType()

* Added canChannel.canAccept() and canChannel.canSetAcceptanceFilter()



