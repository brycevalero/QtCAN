var searchData=
[
  ['remote_20device_20api_20_28kvrlib_29',['Remote Device API (kvrlib)',['../page_kvrlib.html',1,'']]]
];
