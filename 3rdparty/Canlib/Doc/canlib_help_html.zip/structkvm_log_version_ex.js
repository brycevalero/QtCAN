var structkvm_log_version_ex =
[
    [ "eanHi", "structkvm_log_version_ex.html#a73c63d799c9f1e268cba1be5fe684b9a", null ],
    [ "eanLo", "structkvm_log_version_ex.html#a2064213b5ba47d0f4c5c841df408ac90", null ],
    [ "fwBuild", "structkvm_log_version_ex.html#a32cfe1d73a15997e475810ae13488da8", null ],
    [ "fwMajor", "structkvm_log_version_ex.html#a58833c28a09ae4d60434b0a2a53c991a", null ],
    [ "fwMinor", "structkvm_log_version_ex.html#a110dbdd6d83918e6f30bdf9080ef4669", null ],
    [ "lioMajor", "structkvm_log_version_ex.html#a992fc1df4a262d763b04194a3df8293f", null ],
    [ "lioMinor", "structkvm_log_version_ex.html#a4e19ea728f04ebb3b3d2966bf1b07280", null ],
    [ "serialNumber", "structkvm_log_version_ex.html#a1f36efa76fac084b62745c8e8ed0a751", null ]
];