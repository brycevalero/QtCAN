var structkvm_log_trigger_ex =
[
    [ "postTrigger", "structkvm_log_trigger_ex.html#a4e2487f0ee9f254009f623eaec4e8c40", null ],
    [ "preTrigger", "structkvm_log_trigger_ex.html#a1563d8fafddebf325c87f5d76482f403", null ],
    [ "timeStamp", "structkvm_log_trigger_ex.html#aa1fa735b38f32cc201831ea72527ec37", null ],
    [ "trigMask", "structkvm_log_trigger_ex.html#a876ab506b9075d4f42219bd68ddbe4f4", null ],
    [ "type", "structkvm_log_trigger_ex.html#af5dcc482d7b811836ff61a4c408c3c78", null ]
];