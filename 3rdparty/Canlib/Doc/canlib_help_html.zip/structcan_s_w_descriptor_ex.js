var structcan_s_w_descriptor_ex =
[
    [ "rxBufSize", "structcan_s_w_descriptor_ex.html#a22031cf318e44e0c0d51be474623e6f5", null ],
    [ "size", "structcan_s_w_descriptor_ex.html#aac913b3a1f6ef005d66bf7a84428773e", null ],
    [ "txBufSize", "structcan_s_w_descriptor_ex.html#a4f409383284eb558a8b4c97e46155799", null ]
];