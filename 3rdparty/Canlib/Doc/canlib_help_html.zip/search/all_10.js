var searchData=
[
  ['real_20time_20clock',['Real Time Clock',['../group__kvm__rtc.html',1,'']]],
  ['remote_20device_20api_20_28kvrlib_29',['Remote Device API (kvrlib)',['../page_kvrlib.html',1,'']]],
  ['raw',['raw',['../structkvm_log_event_ex.html#a2d78703fd9a85a4cb3ead816db9038bc',1,'kvmLogEventEx']]],
  ['request_5fconnection',['request_connection',['../structkvr_device_info.html#a2d0ed331650715b2758668e03c6ecd2c',1,'kvrDeviceInfo']]],
  ['reserved',['reserved',['../struct_j1587_message_info.html#a3415ebf9c5050a50fa3ae127df65e763',1,'J1587MessageInfo']]],
  ['reserved1',['reserved1',['../structkvr_device_info.html#ae67e2c0ec4e8c9e9504a0f38e7415084',1,'kvrDeviceInfo']]],
  ['reserved2',['reserved2',['../structkvr_device_info.html#a42a59db44a2f07b7fcbe7c4de3f7cba7',1,'kvrDeviceInfo']]],
  ['retries',['retries',['../struct_j1587_message_info.html#a89d4147f125445dabe7483285cf75e2d',1,'J1587MessageInfo']]],
  ['right',['right',['../structtag__token.html#afa54f74105f850a372148e16dde90651',1,'tag_token']]],
  ['rtc',['rtc',['../structkvm_log_event_ex.html#a1f9964cb31c1515adcee1dc69c01d41b',1,'kvmLogEventEx']]],
  ['rxbufsize',['rxBufSize',['../structtag_can_s_w_descr.html#a22031cf318e44e0c0d51be474623e6f5',1,'tagCanSWDescr::rxBufSize()'],['../structcan_s_w_descriptor_ex.html#a22031cf318e44e0c0d51be474623e6f5',1,'canSWDescriptorEx::rxBufSize()']]]
];
