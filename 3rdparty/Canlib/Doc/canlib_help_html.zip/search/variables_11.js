var searchData=
[
  ['usage',['usage',['../structkvr_device_info.html#a5d7b59852b350ed10c69d80f25a15c37',1,'kvrDeviceInfo']]]
];
