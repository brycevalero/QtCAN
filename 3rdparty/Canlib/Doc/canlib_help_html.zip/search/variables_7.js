var searchData=
[
  ['host_5fname',['host_name',['../structkvr_device_info.html#af30d16605d5c80183cd199983a653081',1,'kvrDeviceInfo']]]
];
