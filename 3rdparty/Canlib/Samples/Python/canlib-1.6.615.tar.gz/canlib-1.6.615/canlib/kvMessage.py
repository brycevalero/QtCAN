from . import deprecation
from .frame import Frame


kvMessage = deprecation.class_replaced("kvMessage", Frame)
