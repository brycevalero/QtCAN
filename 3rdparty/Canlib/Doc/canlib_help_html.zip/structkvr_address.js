var structkvr_address =
[
    [ "address", "structkvr_address.html#afd449f94a650582f7a2d0a4bcd14928a", null ],
    [ "type", "structkvr_address.html#ad44b615021ed3ccb734fcaf583ef4a03", null ]
];